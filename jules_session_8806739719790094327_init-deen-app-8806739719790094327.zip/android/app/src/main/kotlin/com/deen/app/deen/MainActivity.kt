package com.deen.app.deen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
