import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:deen/main.dart';

void main() {
  testWidgets('Foundation smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const ProviderScope(child: DeenApp()));

    // Verify that the Home screen is shown by default.
    expect(find.text('Daily Ayah'), findsOneWidget);
    expect(find.text('Daily Hadith'), findsOneWidget);

    // Verify bottom navigation items exist.
    expect(find.byIcon(Icons.home), findsOneWidget);
    expect(find.byIcon(Icons.book_outlined), findsOneWidget);
    expect(find.byIcon(Icons.access_time_outlined), findsOneWidget);
    expect(find.byIcon(Icons.favorite_border), findsOneWidget);
    expect(find.byIcon(Icons.more_horiz), findsOneWidget);

    // Navigate to Quran screen.
    await tester.tap(find.byIcon(Icons.book_outlined));
    await tester.pumpAndSettle();
    expect(find.text('Quran Screen Placeholder'), findsOneWidget);

    // Navigate back to Home screen.
    await tester.tap(find.byIcon(Icons.home_outlined));
    await tester.pumpAndSettle();
    expect(find.text('Daily Ayah'), findsOneWidget);
  });
}
